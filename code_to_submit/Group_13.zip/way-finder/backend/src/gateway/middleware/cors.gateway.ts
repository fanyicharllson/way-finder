import { Request, Response, NextFunction } from "express";
import { Logger } from "../../utils/logger.util";

/**
 * API Gateway - CORS Configuration Middleware
 *
 * Centralized CORS handling for all routes
 * Single place to configure allowed origins
 */

export const corsGateway = (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  // Allowed origins
  const allowedOrigins = [
    "http://localhost:4200",
    "http://localhost:4201",
    "http://localhost:5173",
    "https://wayfinder-api.charlseempire.tech",
    process.env.FRONTEND_URL,
  ].filter(Boolean);

  const origin = req.headers.origin;

  if (allowedOrigins.includes(origin as string)) {
    res.header("Access-Control-Allow-Origin", origin);
    Logger.info(`✅ CORS allowed for origin: ${origin}`);
  } else if (origin) {
    Logger.info(`🚫 CORS rejected for origin: ${origin}`);
  }

  // CORS headers
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH");
  res.header("Access-Control-Allow-Headers", "Content-Type, Authorization");
  res.header("Access-Control-Allow-Credentials", "true");
  res.header("Access-Control-Max-Age", "86400"); // 24 hours

  // Handle preflight requests
  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }

  next();
};
