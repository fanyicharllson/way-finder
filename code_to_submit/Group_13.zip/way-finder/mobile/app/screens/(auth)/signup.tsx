import RegisterScreenComponent from "@/components/screens.components/signup.component";
import { router } from "expo-router";

export default function RegisterRoute() {
  return (
    <RegisterScreenComponent
      onNavigateToLogin={() => router.push("/screens/(auth)/login")}
      onRegisterSuccess={() => {
        // After successful registration, go to preference ui
        router.replace("/screens/(extrascreens)/preferences");
      }}
    />
  );
}
